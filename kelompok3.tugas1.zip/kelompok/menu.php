nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">

<a class="navbar-brand" href="index.php">Persediaan</a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls

"navbar Collapse" aria-expanded="false" aria-label="Toggle navigation">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="navbarCollapse">

<ul class="navbar-nav mr-auto">

<li class="nav-item">

<a class="nav-link" href="petugas.php">Petugas <</a>

</li>

<li class="nav-item">

<a class="nav-link" href="barang.php">Barang</a>

<11>

<li class="nav-item">

<a class="nav-link" href="pelanggan.php">Pelanggan</a>

</11>

<li class="nav-item">

<a class="nav-link" href="supplier.php">Supplier</a>

<11>

<li class="nav-item">

<a class="nav-link" href "barangmasuk.php">Masuk</a>

</11>

<li class="nav-item">

<a class="nav-link" href="barangkeluar.php">Keluar</a>

</li>

</ul>

<form class="form-inline mt-2 at-md-0">

<input class="form-control mr-sm-2" type="text" placeholder "Search" aria-label-"Search">

Chutton class="btn btn-outline-success my-2 my-sa-0" type="submit">Search</button>

</form>

</div>

</nav>