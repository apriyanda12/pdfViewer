<?php
$server = "localhost";
$database = "db_persediaan";
$username = "root";
$password = ""
$koneksidb = mysqli_connect($server, $username, $password, $database);

?>